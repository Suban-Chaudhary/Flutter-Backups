package com.example.hungerz_kiosk

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
