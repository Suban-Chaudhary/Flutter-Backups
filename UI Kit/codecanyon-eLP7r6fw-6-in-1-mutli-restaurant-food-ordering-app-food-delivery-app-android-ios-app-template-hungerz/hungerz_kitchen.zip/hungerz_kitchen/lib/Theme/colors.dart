import 'package:flutter/material.dart';

Color buttonColor = Color(0xffED3F40);
Color blackColor = Colors.black;
Color? strikeThroughColor = Colors.grey[400];
Color newOrderColor = Color(0xff009946);
Color primaryColor = Color(0xffFBAF03);
Color textColor = Color(0xff4D4D4D);
