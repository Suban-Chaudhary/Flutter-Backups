Map<String, String> indonesian() {
  return {
    'foodInsight': 'Makanan Insight',
    'table': 'Meja',
    'today': 'HARI INI',
    'week': 'MINGGU',
    'month': 'BULAN',
    'backToOrder': 'Kembali ke Orde',
    'jan': 'jan',
    'totalOrders': 'total pesanan',
    'totalItems': 'jumlah barang',
    'timeCooked': 'waktu dimasak',
    'mostPopularItems': 'ITEM PALING POPULER',
    'kitchen': 'DAPUR',
    'pastOrders': 'masa lalu Pesanan',
    'noDataToShow': 'Tidak ada Data Untuk Tampilkan',
    'enterMobileNumber': 'Masukkan Nomor Handphone',
    'continuee': 'Terus',
    'close': 'Menutup',
  };
}
