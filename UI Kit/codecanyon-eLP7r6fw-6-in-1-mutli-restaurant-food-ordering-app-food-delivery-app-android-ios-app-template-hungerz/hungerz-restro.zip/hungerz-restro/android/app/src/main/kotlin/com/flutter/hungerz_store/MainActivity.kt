package com.flutter.hungerz_store

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
