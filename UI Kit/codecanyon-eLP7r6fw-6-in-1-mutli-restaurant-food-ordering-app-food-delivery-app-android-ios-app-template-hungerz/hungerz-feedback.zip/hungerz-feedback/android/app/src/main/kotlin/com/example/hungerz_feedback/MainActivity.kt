package com.example.hungerz_feedback

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
