Map<String, String> indonesian() {
  return {
    'welcome': 'Selamat datang',
    'continueText': 'Terus',
    'enterRegistered': 'ENTER TERDAFTAR',
    'phoneNumberToStart': 'NOMOR TELEPON UNTUK MULAI',
    'phoneNumber': 'NOMOR TELEPON',
    'wellSendCode':
        'Kami akan mengirimkan kode verifikasi di atas angka yang diberikan',
    'enterVerificationCode': 'MASUKKAN KODE VERIFIKASI',
    'sentOnNumber': 'DIKIRIM PADA NOMOR DIBERIKAN',
    'submit': 'Kirimkan',
    'giveYour': 'Berikan',
    'feedback': 'Masukan',
    'yourWordMeansALot': 'ANDA KATA BERARTI BANYAK UNTUK AS',
    'bringItOn': 'AYO',
    'howWas': 'Bagaimana kualitas makanan?',
    'cancel': 'MEMBATALKAN',
    'next': 'LANJUT',
    'thankYouFor': 'Terima kasih untuk',
    'yourFeedback': 'Masukan Anda',
    'weWillTry': 'KAMI AKAN MENCOBA TERBAIK UNTUK MEMBERIKAN Serivces KUALITAS',
  };
}
