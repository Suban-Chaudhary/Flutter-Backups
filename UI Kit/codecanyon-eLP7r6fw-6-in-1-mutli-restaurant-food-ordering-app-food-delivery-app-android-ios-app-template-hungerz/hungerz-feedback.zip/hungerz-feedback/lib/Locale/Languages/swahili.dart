Map<String, String> swahili() {
  return {
    'welcome': 'Karibu',
    'continueText': 'kuendelea',
    'enterRegistered': 'ENTER Registered',
    'phoneNumberToStart': 'PHONE NUMBER NA START',
    'phoneNumber': 'NAMBARI YA SIMU',
    'wellSendCode':
        'Tutakutumia nambari ya kuthibitisha kwenye juu idadi fulani',
    'enterVerificationCode': 'ENTER ya kuthibitisha',
    'sentOnNumber': 'SENT ON NUMBER GIVEN',
    'submit': 'wasilisha',
    'giveYour': 'kutoa yako',
    'feedback': 'maoni',
    'yourWordMeansALot': 'YOUR maana ya neno A LOT YA Marekani',
    'bringItOn': 'Twende kazi',
    'howWas': 'Je, ubora wa chakula?',
    'cancel': 'GHAIRI',
    'next': 'NEXT',
    'thankYouFor': 'Asante kwa',
    'yourFeedback': 'Maoni yako',
    'weWillTry': 'Sisi kujaribu bora yetu ya kutoa serivces QUALITY',
  };
}
