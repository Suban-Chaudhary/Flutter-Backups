class Category {
  final String image;
  final String? title;

  Category(this.image, this.title);
}
