import 'package:flutter/material.dart';

Color buttonColor = Color(0xffED3F40);
Color blackColor = Colors.black;
Color? strikeThroughColor = Colors.grey[400];
Color newOrderColor = Color(0xff009946);
Color transparentColor = Colors.transparent;