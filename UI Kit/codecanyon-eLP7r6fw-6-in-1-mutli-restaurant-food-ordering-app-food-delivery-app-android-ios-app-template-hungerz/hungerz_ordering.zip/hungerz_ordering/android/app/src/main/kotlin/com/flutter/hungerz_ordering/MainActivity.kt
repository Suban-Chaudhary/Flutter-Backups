package com.flutter.hungerz_ordering

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
